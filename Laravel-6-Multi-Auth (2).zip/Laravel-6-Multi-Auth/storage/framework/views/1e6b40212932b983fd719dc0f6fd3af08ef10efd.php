<!DOCTYPE html>
<html>
<head>
    <title>Add/remove multiple input fields dynamically with Jquery Laravel 5.8</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</head>
<body>
   
<div class="container">
    <h2 align="center">Add/remove multiple input fields dynamically with Jquery Laravel 5.8</h2> 
   
    <form action="<?php echo e(route('json.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
   
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
   
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success text-center">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                <p><?php echo e(Session::get('success')); ?></p>
            </div>
        <?php endif; ?>
   
        <div id="dynamicTable">
            <input type="text" name="name"  placeholder="Enter your Name" class="form-control" />
            <tr>  
                <td><input type="number"  name="phone[]" placeholder="Enter your phone" class="form-control" /></td>  
                 
                <td><button type="button" name="add" id="add" class="btn btn-success">Add More</button></td>  
            </tr>  
         </div>
    
        <button type="submit" class="btn btn-success">Save</button>
    </form>
</div>
    
<script type="text/javascript">
   
    var i = 0;
       
    $("#add").click(function(){
   
        ++i;
   
        $("#dynamicTable").append('<tr><td><input type="number"  name="phone[]" placeholder="Enter your phone" class="form-control" /></td><td><button type="button" class="btn btn-danger remove-tr">Remove</button></td></tr>');
    });
   
    $(document).on('click', '.remove-tr', function(){  
         $(this).parents('tr').remove();
    });  
   
</script>
  
</body>
</html><?php /**PATH E:\wamp2\www\Laravel-6-Multi-Auth\resources\views/json/index.blade.php ENDPATH**/ ?>