<?php $__env->startSection('content'); ?>
<table id="cart" class="table table-hover table-condensed">
        <thead>
        <tr>
            <th >Name</th>
            <th >Phone</th>
             <th >Action</th>
            
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($p['name']); ?></td>
                 <td><?php
                 $a1 = $p['phone'];$a1=implode(', ',$a1);
                 echo $a1;
                 ?></td>
       <td> <a href="<?php echo e(route('json.edit', $p->id)); ?>"  class="btn btn-warning">Edit<?php echo e($p->id); ?></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
       
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp2\www\Laravel-6-Multi-Auth\resources\views/json/show.blade.php ENDPATH**/ ?>