<?php $__env->startSection('content'); ?>
 <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
           
            <br />
     <form method="post" action="<?php echo e(route('crud.update', $data->id)); ?>" >
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <?php
                 $a1 = $data['phone'];$a1=implode(', ',$a1);                
                 ?>
              Name: <input type="text" name="name" value="<?php echo e($data['name']); ?>"><br/><br/>
                 Phone: <input type="text" name="phone[]" value="<?php echo e($a1); ?>"><br/><br/>
     
     
     </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp2\www\Laravel-6-Multi-Auth\resources\views/json/edit.blade.php ENDPATH**/ ?>