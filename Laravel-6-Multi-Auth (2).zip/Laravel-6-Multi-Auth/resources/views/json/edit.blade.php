@extends('layouts.app')
@section('content')
 @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
           
            <br />
     <form method="post" action="{{ route('crud.update', $data->id) }}" >
                @csrf
                @method('PATCH')
                <?php
                 $a1 = $data['phone'];$a1=implode(', ',$a1);                
                 ?>
              Name: <input type="text" name="name" value="{{$data['name']}}"><br/><br/>
                 Phone: <input type="text" name="phone[]" value="{{$a1}}"><br/><br/>
     
     
     </form>

@endsection