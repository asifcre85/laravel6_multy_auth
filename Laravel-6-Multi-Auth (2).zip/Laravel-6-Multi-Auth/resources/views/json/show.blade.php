@extends('layout')
@section('content')
<table id="cart" class="table table-hover table-condensed">
        <thead>
        <tr>
            <th >Name</th>
            <th >Phone</th>
             <th >Action</th>
            
        </tr>
        </thead>
        <tbody>
            @foreach($a as $p)
            <tr>
                <td>{{$p['name']}}</td>
                 <td><?php
                 $a1 = $p['phone'];$a1=implode(', ',$a1);
                 echo $a1;
                 ?></td>
       <td> <a href="{{ route('json.edit', $p->id) }}"  class="btn btn-warning">Edit{{$p->id}}</a></td>
            </tr>
            @endforeach
        </tbody>
       