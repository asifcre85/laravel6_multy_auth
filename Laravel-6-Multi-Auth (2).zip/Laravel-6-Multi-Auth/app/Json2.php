<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Json2 extends Model
{
	protected $fillable = [
     'name', 'phone'
    ];

    protected $casts = [
    'phone' => 'array',
  ];
}
